<h1>Chào mứng đến với khóa học Laravel</h1>
<a href="{{ route('page.about') }}">About</a>
