<h1>Chào mứng đến với khóa học Laravel</h1>
<a href="<?php echo e(route('page.about')); ?>">About</a>
<?php /**PATH C:\laragon\www\wd18318laravel\resources\views/test.blade.php ENDPATH**/ ?>