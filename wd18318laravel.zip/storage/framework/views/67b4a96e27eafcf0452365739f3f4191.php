<h1>Giới thiệu về website</h1>
<?php /**PATH C:\laragon\www\wd18318laravel\resources\views/about.blade.php ENDPATH**/ ?>